#Part 1
#Binomial Distribution
#Here, Random variable x has a binomial distribution with x=50 and p = 0.85
pbinom(47,55,0.85,lower.tail = "False")

#Part 2
#Number of calls receive in an hour
#Poisson Distribution
#Here, Random variable x has a binomial distribution with lambda = 12
dpois(15,12)


